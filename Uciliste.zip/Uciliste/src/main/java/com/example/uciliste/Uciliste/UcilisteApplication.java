package com.example.uciliste.Uciliste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UcilisteApplication {

	public static void main(String[] args) {
		SpringApplication.run(UcilisteApplication.class, args);
	}

}
